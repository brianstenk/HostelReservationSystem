package org.miu.edu.exceptions;

public class ReservationException extends Exception {

	private static final long serialVersionUID = 3606134170452129617L;

	public ReservationException(String message) {
		super(message);
	}
	
	public ReservationException() {
		super();
	}
}