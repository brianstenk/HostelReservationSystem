package org.miu.edu.exceptions;

public class TooManyBedsException extends Exception {

	private static final long serialVersionUID = 3606134170452129617L;

	public TooManyBedsException(String message) {
		super(message);
	}
	
	public TooManyBedsException() {
		super();
	}
}