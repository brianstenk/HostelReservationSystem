package org.miu.edu.exceptions;

public class WrongBedTypeException extends Exception {

	private static final long serialVersionUID = 3606134170452129617L;

	public WrongBedTypeException(String message) {
		super(message);
	}
	
	public WrongBedTypeException() {
		super();
	}
}