package org.miu.edu.model;

public interface ComputeRoomDailyRate {
	
	double computeDailyRate();
}