package org.miu.edu.model;

public enum RoomType {
	SINGLE, DOUBLE, DORM
}