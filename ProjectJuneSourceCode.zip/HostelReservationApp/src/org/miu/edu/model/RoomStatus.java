package org.miu.edu.model;

public enum RoomStatus {
	AVAILABLE, BOOKED
}