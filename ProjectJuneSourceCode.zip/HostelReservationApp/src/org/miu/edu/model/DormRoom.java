
package org.miu.edu.model;

public class DormRoom extends Room implements ComputeRoomDailyRate {

	private static final long serialVersionUID = 8187721648019325247L;

	public DormRoom(RoomStatus status, String decription, int maxNoOfBeds, int roomId) {
		super(status, decription, maxNoOfBeds, roomId);
	}
	
	@Override  
	public double computeDailyRate() {
		double rate = 0;
		
		for (Bed bed : this.getBeds()) {
			rate += bed.getDailyRate();
		}
		return rate;
	}
}