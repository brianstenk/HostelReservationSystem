package org.miu.edu.model;

public enum BedType {
	UPPER, LOWER, SINGLE, DOUBLE
}