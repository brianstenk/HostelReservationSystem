package org.miu.edu.model;

public enum BedStatus {
	AVAILABLE, BOOKED
}