
package org.miu.edu.model;

import java.io.Serializable;

public class Bed implements Serializable {

	private static final long serialVersionUID = -5760939777858776770L;
	
	private int id;
	
	private BedStatus bedStatus;
	
	private double dailyRate;
	
	private BedType bedType;
	
	public Bed() {}
	
	public Bed(int id, BedStatus bedStatus, BedType bedType) {
		super();
		this.id = id;
		this.setBedStatus(bedStatus);
		this.bedType = bedType;
	}

	public Bed(int id, BedStatus bedStatus, double dailyRate, BedType bedType) {
		super();
		this.id = id;
		this.setBedStatus(bedStatus);
		this.dailyRate = dailyRate;
		this.bedType = bedType;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public BedStatus getBedStatus() {
		return bedStatus;
	}

	public void setBedStatus(BedStatus bedStatus) {
		this.bedStatus = bedStatus;
	}

	public double getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(double dailyRate) {
		this.dailyRate = dailyRate;
	}

	public BedType getBedType() {
		return bedType;
	}

	public void setBedType(BedType bedType) {
		this.bedType = bedType;
	}
	
	public String getBedId() {
		return String.valueOf(id);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + this.getId();
		return result;
	}

	@Override
	public boolean equals(Object ob) {
		if(ob == null || ob.getClass() != getClass()) 
			return false;
		Bed bed = (Bed)ob;
		return bed.getId() == this.getId();
	}
}