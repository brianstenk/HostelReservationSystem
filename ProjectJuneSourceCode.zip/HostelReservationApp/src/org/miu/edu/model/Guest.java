package org.miu.edu.model;

import java.io.Serializable;

public class Guest implements Serializable {

	private static final long serialVersionUID = 9220791455318216889L;
	
	private String address;
	
	private String firstName;
	
	private String lastName;
	
	private String phoneNumber;
	
	private String personalID;

	public Guest() {
		super();
	}

	public Guest(String address, String firstName, String lastName, String phoneNumber, String personalID) {
		super();
		this.address = address;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.personalID = personalID;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPersonalID() {
		return personalID;
	}

	public void setPersonalID(String personalID) {
		this.personalID = personalID;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result;
		return result;
	}

	@Override
	public boolean equals(Object ob) {
		if(ob == null || ob.getClass() != getClass()) 
			return false;
		Guest guest = (Guest)ob;
		return guest.getPersonalID() == this.getPersonalID();
	}
}