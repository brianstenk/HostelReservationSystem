package org.miu.edu.model;

import org.miu.edu.exceptions.TooManyBedsException;
import org.miu.edu.exceptions.WrongBedTypeException;

public class SingleRoom extends Room implements ComputeRoomDailyRate {

	private static final long serialVersionUID = -1810463198943981324L;
	
	private double dailyRate;

	public SingleRoom(RoomStatus status, String decription, int maxNoOfBeds, double dailyRate, int roomId) {
		super(status, decription, maxNoOfBeds, roomId);
		this.dailyRate = dailyRate;
	}
	
	@Override  
	public double computeDailyRate() {
		return this.getDailyRate();
	}

	public double getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(double dailyRate) {
		this.dailyRate = dailyRate;
	}
	
	/**
	 * Adds one bed at a time
	 */
	@Override
	public void addBed(Bed bed) throws TooManyBedsException, WrongBedTypeException {
		if (this.getBeds().size() < this.getMaxNoOfBeds()) {
			if (!bed.getBedType().equals(BedType.SINGLE))
				throw new WrongBedTypeException();
			else {
				this.getBeds().add(bed);
			}
		} else {
			throw new TooManyBedsException();
		}
	}
}