package org.miu.edu.model;

import java.io.Serializable;

public class User implements Serializable {

	private static final long serialVersionUID = -3012477100088209926L;
	
	private int id;
	
	private String emailAddress;
	
	private UserType userType;
	
	private String password;
	
	public User() {
		super();
	}

	public User(String emailAddress, UserType userType, String password) {
		super();
		this.emailAddress = emailAddress;
		this.userType = userType;
		this.password = password;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public UserType getUserType() {
		return userType;
	}

	public void setUserType(UserType userType) {
		this.userType = userType;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}