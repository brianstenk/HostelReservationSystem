
package org.miu.edu.model;

import java.io.Serializable;
import java.util.Date;

public class Reservation implements Serializable {

	private static final long serialVersionUID = 2162715178638817021L;

	private int reservationId;
	
	private Date checkInDate;
	
	private Date checkOutDate;
	
	private Room room;
	
	private Guest guest;
	
	private PaymentType paymentType;
	
	private ReservationStatus reservationStatus;
	
	private String summary;
	
	private User user;

	public Reservation(Date checkInDate, Date checkOutDate, Room room, Guest guest, PaymentType paymentType,
			ReservationStatus reservationStatus, User user) {
		super();
		this.setCheckInDate(checkInDate);
		this.setCheckOutDate(checkOutDate);
		this.room = room;
		this.guest = guest;
		this.paymentType = paymentType;
		this.reservationStatus = reservationStatus;
		this.user = user;
	}
	
	public int getReservationId() {
		return reservationId;
	}

	public void setReservationId(int reservationId) {
		this.reservationId = reservationId;
	}

	public Date getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(Date checkInDate) {
		this.checkInDate = checkInDate;
		
	}

	public Date getCheckOutDate() {
		return checkOutDate;
	}

	public void setCheckOutDate(Date checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	public Guest getGuest() {
		return guest;
	}

	public void setGuest(Guest guest) {
		this.guest = guest;
	}

	public PaymentType getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}

	public ReservationStatus getReservationStatus() {
		return reservationStatus;
	}

	public void setReservationStatus(ReservationStatus reservationStatus) {
		this.reservationStatus = reservationStatus;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result;
		return result + this.getReservationId();
	}

	@Override
	public boolean equals(Object ob) {
		if(ob == null || ob.getClass() != getClass()) 
			return false;
		Reservation reservation = (Reservation)ob;
		return reservation.getReservationId() == this.getReservationId();
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}