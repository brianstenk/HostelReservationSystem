package org.miu.edu.model;

public enum ReservationStatus {
	CANCELLED, CHECKED_OUT, ACTIVE
}