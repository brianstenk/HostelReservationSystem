
package org.miu.edu.model;

import org.miu.edu.exceptions.TooManyBedsException;
import org.miu.edu.exceptions.WrongBedTypeException;

public class DoubleRoom extends Room implements ComputeRoomDailyRate {

	private static final long serialVersionUID = 8187721648019325247L;
	
	private double dailyRate;

	public DoubleRoom(RoomStatus status, String decription, int maxNoOfBeds, double dailyRate, int roomId) {
		super(status, decription, maxNoOfBeds, roomId);
		this.dailyRate = dailyRate;
	}
	
	@Override  
	public double computeDailyRate() {
		return this.getDailyRate();
	}

	public double getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(double dailyRate) {
		this.dailyRate = dailyRate;
	}
	
	@Override
	public void addBed(Bed bed) throws TooManyBedsException, WrongBedTypeException {
		if (this.getBeds().size() < this.getMaxNoOfBeds()) {
			
			if (this.getBeds().size() > 0) {
				Bed existingBed = this.getBeds().get(0);
				
				if (existingBed.getBedType().equals(BedType.DOUBLE)) {
					throw new TooManyBedsException();
				} else if (existingBed.getBedType().equals(BedType.SINGLE)) {
					this.getBeds().add(bed);
				}
			} else {
				if (bed.getBedType() == BedType.DOUBLE || bed.getBedType() == BedType.SINGLE) {
					this.getBeds().add(bed);	
				} else 
					throw new WrongBedTypeException();
			}
		} else {
			throw new TooManyBedsException();
		}
	}
}