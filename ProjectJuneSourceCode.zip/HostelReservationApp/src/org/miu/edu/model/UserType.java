package org.miu.edu.model;

public enum UserType {
	USER, ADMIN, BOTH
}