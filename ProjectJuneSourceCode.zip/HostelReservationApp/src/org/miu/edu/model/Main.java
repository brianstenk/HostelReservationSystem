
package org.miu.edu.model;

public class Main {

	public static void main(String[] args) {

		/*System.out.println("--------------------------------------");
		System.out.println("Hostel Reservation System v1");
		System.out.println("--------------------------------------");

		Vector<Room> rooms = new Vector<>(Arrays
				.asList(new Room[] { new SingleRoom("Single Room A", 10000), 
						new SingleRoom("Single Room B", 12000),
						new DoubleRoom("Double Room A", 20000), 
						new DormRoom("Dorm Room A", 25000)
				}));

		for (Room rm: rooms ) {
			System.out.println(rm.getRoomType());
		}*/
	}
}
