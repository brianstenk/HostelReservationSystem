package org.miu.edu.model;

public enum PaymentType {
	CREDIT, CASH
}
