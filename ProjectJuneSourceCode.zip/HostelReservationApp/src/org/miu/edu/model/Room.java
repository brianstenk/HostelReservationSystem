package org.miu.edu.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.miu.edu.exceptions.TooManyBedsException;
import org.miu.edu.exceptions.WrongBedTypeException;

public class Room implements Serializable {

	private static final long serialVersionUID = -8588082098809182507L;

	private int roomId;

	private RoomStatus status;

	private String description;

	private int maxNoOfBeds;

	private List<Bed> beds;

	Room() {
		super();
		this.beds = new ArrayList<Bed>();
	}

	Room(RoomStatus status, String description, int maxNoOfBeds, int roomId) {
		super();
		this.status = status;
		this.description = description;
		this.maxNoOfBeds = maxNoOfBeds;
		this.roomId = roomId;
		this.beds = new ArrayList<Bed>();
	}
	
	public boolean isRoomAvailable() {
		return this.status == RoomStatus.AVAILABLE;
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public RoomStatus getStatus() {
		return status;
	}

	public void setStatus(RoomStatus status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getMaxNoOfBeds() {
		return maxNoOfBeds;
	}

	public void setMaxNoOfBeds(int maxNoOfBeds) {
		this.maxNoOfBeds = maxNoOfBeds;
	}

	public List<Bed> getBeds() {
		return beds;
	}

	public void setBeds(List<Bed> beds) {
		this.beds = beds;
	}

	public void addBed(Bed bed) throws TooManyBedsException, WrongBedTypeException {
		if (beds.size() < maxNoOfBeds) {
			this.beds.add(bed);
		} else {
			throw new TooManyBedsException();
		}
	}
	
	public String getBedSummaryInfo() {
		String result = null;
		for (Bed bed : beds) {
			if (result == null)
				result = bed.getBedId();
			else
				result = result + "," + bed.getBedId();
		}
		return result;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + this.getRoomId();
		return result;
	}

	@Override
	public boolean equals(Object ob) {
		if(ob == null || ob.getClass() != getClass()) 
			return false;
		Room room = (Room)ob;
		return room.getRoomId() == this.getRoomId();
	}
	
	@Override
	public String toString() {
		return this.roomId + " " + this.description + " " + this.status;
	}
}