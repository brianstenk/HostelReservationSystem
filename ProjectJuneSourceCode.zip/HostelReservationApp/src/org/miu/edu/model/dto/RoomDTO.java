package org.miu.edu.model.dto;

import java.io.Serializable;

import org.miu.edu.model.DormRoom;
import org.miu.edu.model.DoubleRoom;
import org.miu.edu.model.Room;
import org.miu.edu.model.RoomStatus;
import org.miu.edu.model.RoomType;
import org.miu.edu.model.SingleRoom;

public class RoomDTO implements Serializable {

	private static final long serialVersionUID = -8588082098809182507L;

	private int roomId;

	private RoomStatus roomStatus;
	
	private RoomType roomType;

	private String name;

	private String description;

	private int maxNoOfBeds;
	
	private int noOfBeds;
	
	private double dailyRate;

	public RoomDTO() {
		super();
	}

	public RoomDTO(Room room) {
		super();
		this.setRoomStatus(room.getStatus());
		this.setDescription(room.getDescription());
		this.maxNoOfBeds = room.getMaxNoOfBeds();
		this.roomId = room.getRoomId();
		this.setNoOfBeds(room.getBeds().size());
		
		if (room instanceof SingleRoom) {
			this.setRoomType(RoomType.SINGLE);
			this.setDailyRate(((SingleRoom)room).computeDailyRate());
		}
		
		if (room instanceof DoubleRoom) {
			this.setRoomType(RoomType.DOUBLE);
			this.setDailyRate(((DoubleRoom)room).computeDailyRate());
		}
		
		if (room instanceof DormRoom) {
			this.setRoomType(RoomType.DORM);
			this.setDailyRate(((DormRoom)room).computeDailyRate());
		}
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMaxNoOfBeds() {
		return maxNoOfBeds;
	}

	public void setMaxNoOfBeds(int maxNoOfBeds) {
		this.maxNoOfBeds = maxNoOfBeds;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + this.getRoomId();
		return result;
	}

	@Override
	public boolean equals(Object ob) {
		if(ob == null || ob.getClass() != getClass()) 
			return false;
		RoomDTO room = (RoomDTO)ob;
		return room.getRoomId() == this.getRoomId();
	}

	public RoomType getRoomType() {
		return roomType;
	}

	public void setRoomType(RoomType roomType) {
		this.roomType = roomType;
	}

	public double getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(double dailyRate) {
		this.dailyRate = dailyRate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getNoOfBeds() {
		return noOfBeds;
	}

	public void setNoOfBeds(int noOfBeds) {
		this.noOfBeds = noOfBeds;
	}

	public RoomStatus getRoomStatus() {
		return roomStatus;
	}

	public void setRoomStatus(RoomStatus roomStatus) {
		this.roomStatus = roomStatus;
	}
}