
package org.miu.edu.model.dto;

import java.io.Serializable;

import org.miu.edu.model.PaymentType;
import org.miu.edu.model.Reservation;
import org.miu.edu.model.ReservationStatus;

public class ReservationDTO implements Serializable {

	private static final long serialVersionUID = 2162715178638817021L;

	private int reservationId;
	
	private String checkInDate;
	
	private String checkOutDate;
	
	private String address;
	
	private String firstName;
	
	private String lastName;
	
	private String phoneNumber;
	
	private String personalID;
	
	private String roomNumber;
	
	private String bedNumber;
	
	private PaymentType paymentType;
	
	private ReservationStatus reservationStatus;
	
	private Reservation reservation;
	
	public ReservationDTO() {
		super();
	}

	public ReservationDTO(int reservationId, String checkInDate, String checkOutDate, String address,
			String firstName, String lastName, String phoneNumber, String personalID, String roomNumber, String bedNumber,
			PaymentType paymentType, ReservationStatus reservationStatus, Reservation reservation) {
		super();
		this.reservationId = reservationId;
		this.checkInDate = checkInDate;
		this.checkOutDate = checkOutDate;
		this.address = address;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.personalID = personalID;
		this.roomNumber = roomNumber;
		this.bedNumber = bedNumber;
		this.paymentType = paymentType;
		this.reservationStatus = reservationStatus;
		this.setReservation(reservation);
	}

	public int getReservationId() {
		return reservationId;
	}

	public void setReservationId(int reservationId) {
		this.reservationId = reservationId;
	}

	public String getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}

	public String getCheckOutDate() {
		return checkOutDate;
	}

	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPersonalID() {
		return personalID;
	}

	public void setPersonalID(String personalID) {
		this.personalID = personalID;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public String getBedNumber() {
		return bedNumber;
	}

	public void setBedNumber(String bedNumber) {
		this.bedNumber = bedNumber;
	}

	public PaymentType getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}

	public ReservationStatus getReservationStatus() {
		return reservationStatus;
	}

	public void setReservationStatus(ReservationStatus reservationStatus) {
		this.reservationStatus = reservationStatus;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result;
		return result + this.getReservationId();
	}

	@Override
	public boolean equals(Object ob) {
		if(ob == null || ob.getClass() != getClass()) 
			return false;
		ReservationDTO reservation = (ReservationDTO)ob;
		return reservation.getReservationId() == this.getReservationId();
	}

	public Reservation getReservation() {
		return reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}
}