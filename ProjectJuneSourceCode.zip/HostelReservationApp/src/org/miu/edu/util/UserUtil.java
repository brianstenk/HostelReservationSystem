package org.miu.edu.util;

import org.miu.edu.dao.UserDao;
import org.miu.edu.dao.impl.UserDaoImpl;
import org.miu.edu.model.User;
import org.miu.edu.model.UserType;

public class UserUtil {

	private static User loggedInUser;

	private static UserDao userDao;

	public static void loadTestUsers() {
		if (getAllUsers().length < 2) {
			User adminUser = new User("admin@test.com", UserType.ADMIN, "admin");
			User bothUser = new User("both@test.com", UserType.BOTH, "both");

			getUserDaoInstance().saveNewUser(adminUser);
			getUserDaoInstance().saveNewUser(bothUser);
		}
	}

	public static void removeAllUsers() {
		getUserDaoInstance().removeAllUsers();
	}

	public static User getLoggedInUser() {
		return loggedInUser;
	}

	public static void setLoggedInUser(User loggedInUser) {
		UserUtil.loggedInUser = loggedInUser;
	}

	public static User[] getAllUsers() {
		return getUserDaoInstance().getAllUsers();
	}

	private static UserDao getUserDaoInstance() {
		if (userDao == null)
			return new UserDaoImpl();
		return userDao;
	}
}