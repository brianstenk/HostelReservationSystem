package org.miu.edu.util;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class WindowUtil {

	public static FXMLLoader loadWindow(String windowName, ActionEvent event, @SuppressWarnings("rawtypes") Class c) {
		FXMLLoader loader = null;
		try {
			loader = new FXMLLoader(c.getResource("/org/miu/edu/views/" + windowName + ".fxml"));
	        Parent root = loader.load();
			Stage appStage = new Stage();
			appStage.setScene(new Scene(root));
			if (!windowName.equalsIgnoreCase("Login") && !windowName.equalsIgnoreCase("Register"))
				appStage.initStyle(StageStyle.UNDECORATED);
			appStage.show();
			((Node) (event.getSource())).getScene().getWindow().hide();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return loader;
	}

	public static void loadPopWindow(String PopupName, ActionEvent event, @SuppressWarnings("rawtypes") Class c) {
		try {
			Parent root = FXMLLoader.load(c.getResource("/org/miu/edu/views/" + PopupName + ".fxml"));
			Stage stage = new Stage();
			stage.setScene(new Scene(root));
			stage.initStyle(StageStyle.UNDECORATED);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static Alert createAlert(String title, String message, AlertType alertType) {
		Alert alert = new Alert(alertType);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		return alert;
	}
}