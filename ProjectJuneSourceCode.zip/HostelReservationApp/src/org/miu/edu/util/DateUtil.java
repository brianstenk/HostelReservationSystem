package org.miu.edu.util;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {

	public static long getTimeDifference(Date start, Date end) {
		LocalDateTime startLdt = LocalDateTime.ofInstant(start.toInstant(), ZoneId.systemDefault());
		LocalDateTime endLdt = LocalDateTime.ofInstant(end.toInstant(), ZoneId.systemDefault());

		Duration duration = Duration.between(startLdt, endLdt);
		long diff = Math.abs(duration.toHours());
		return diff;
	}
	
	public static boolean isBefore(Date start, Date end) {
		LocalDateTime startLdt = LocalDateTime.ofInstant(start.toInstant(), ZoneId.systemDefault());
		LocalDateTime endLdt = LocalDateTime.ofInstant(end.toInstant(), ZoneId.systemDefault());
		return startLdt.isBefore(endLdt);
	}

	public static Date convertLocalDateToDate(LocalDate dateToConvert) {
		Date date = java.sql.Date.valueOf(dateToConvert);
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
	    calendar.add(Calendar.HOUR_OF_DAY, 14);
	    calendar.add(Calendar.MINUTE, 0);
	    calendar.add(Calendar.SECOND, 0);
		return calendar.getTime();
	}

	public static LocalDateTime convertDateToLocalDateTime(Date dateToConvert) {
		return dateToConvert.toInstant()
				.atZone(ZoneId.systemDefault())
				.toLocalDateTime();
	}

	public static String getFormattedDate(Date inputDate) {
		String datePattern = "dd-MM-yyyy hh:mm:ss";
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(datePattern);
		return dateFormatter.format(convertDateToLocalDateTime(inputDate));
	}
	
	public static LocalDate convertDateToLocalDate(Date dateToConvert) {
	    return dateToConvert.toInstant()
	      .atZone(ZoneId.systemDefault())
	      .toLocalDate();
	}
}
