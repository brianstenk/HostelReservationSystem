package org.miu.edu.dao;

import java.util.HashMap;

import org.miu.edu.model.User;

public interface UserDao {
	
	public HashMap<Integer, User> readUsersMap();
	
	public void updateUser(User user);
	
	public void saveNewUser(User user);
	
	public User[] getAllUsers();
	
	public void removeAllUsers();
	
	public User authenticateUser(String emailAddress, String password);
}