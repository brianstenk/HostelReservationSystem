package org.miu.edu.dao;

import java.time.LocalDate;
import java.util.HashMap;

import org.miu.edu.exceptions.TooManyBedsException;
import org.miu.edu.exceptions.WrongBedTypeException;
import org.miu.edu.model.Bed;
import org.miu.edu.model.BedType;
import org.miu.edu.model.Room;

public interface RoomDao {
	
	public HashMap<Integer, Room> readRoomsMap();
	
	public Room[] getAllRooms();
	
	public Room[] getAllUnReservedRooms(LocalDate startDate, LocalDate endDate);
	
	public void addBedToRoom(int roomId, Bed bed) throws TooManyBedsException, WrongBedTypeException;

	public void saveRoom(Room room);
	
	public boolean updateRoom(int roomId, String description, int maxNoOfBeds, double dailyRate) throws TooManyBedsException;
	
	public boolean updateBed(int roomId, int bedId, BedType bedType, double dailyRate) throws WrongBedTypeException;
	
	public Room deleteRoom(int roomId);	
	
	public boolean removeBedFromRoom(int roomID, int bedId);
	
	public void saveNewRoom(Room room);
	
	public Room bookBed(int roomID, int bedId);
	
	public Room bookRoom(int roomID);
	
	public Room performCheckOut(int roomID, String bedIds);
	
	public Room getRoom(Integer roomID);
	
	public String[] getAvailableBeds(Integer roomID);
}