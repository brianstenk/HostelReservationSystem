package org.miu.edu.dao;

import java.util.HashMap;
import java.util.List;

import org.miu.edu.model.Reservation;

public interface ReservationDao {
	public HashMap<Integer, Reservation> readReservationsMap();
	
	public Reservation cancelReservation(int reservationId);
	
	public void saveNewReservation(Reservation reservation);
	
	public List<Reservation> getAllReservations(boolean doFiltering);
	
	public Reservation getReservation(int reservationId);
	
	public void updateReservation(Reservation reservation);
	
	public Reservation performCheckOut(int reservationId);
}