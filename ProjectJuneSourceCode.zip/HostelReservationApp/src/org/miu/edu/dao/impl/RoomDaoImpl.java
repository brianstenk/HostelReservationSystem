package org.miu.edu.dao.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.miu.edu.dao.ReservationDao;
import org.miu.edu.dao.RoomDao;
import org.miu.edu.dao.impl.Storage.StorageType;
import org.miu.edu.exceptions.TooManyBedsException;
import org.miu.edu.exceptions.WrongBedTypeException;
import org.miu.edu.model.Bed;
import org.miu.edu.model.BedStatus;
import org.miu.edu.model.BedType;
import org.miu.edu.model.DormRoom;
import org.miu.edu.model.DoubleRoom;
import org.miu.edu.model.Reservation;
import org.miu.edu.model.Room;
import org.miu.edu.model.RoomStatus;
import org.miu.edu.model.SingleRoom;
import org.miu.edu.util.DateUtil;

public class RoomDaoImpl implements RoomDao {

	public void saveNewRoom(Room room) {
		HashMap<Integer, Room> rooms = readRoomsMap();
		int roomId = room.getRoomId();
		rooms.put(roomId, room);
		Storage.saveToStorage(StorageType.ROOMS, rooms);
	}

	public void saveRoom(Room room) {
		HashMap<Integer, Room> rooms = readRoomsMap();
		rooms.put(room.getRoomId(), room);
		Storage.saveToStorage(StorageType.ROOMS, rooms);
	}

	@SuppressWarnings("unchecked")
	public HashMap<Integer, Room> readRoomsMap() {
		Object o = Storage.readFromStorage(StorageType.ROOMS);
		if(o == null)
			return new HashMap<Integer, Room>();
		return (HashMap<Integer, Room>)o ;
	}

	@Override
	public Room[] getAllRooms() {
		HashMap<Integer, Room> roomsMap = readRoomsMap();
		return roomsMap.values().toArray(new Room[] {});
	}

	@Override
	public void addBedToRoom(int roomId, Bed bed) throws TooManyBedsException, WrongBedTypeException {
		HashMap<Integer, Room> rooms = readRoomsMap();
		Room room = rooms.get(roomId);
		room.addBed(bed);
		rooms.put(room.getRoomId(), room);
		Storage.saveToStorage(StorageType.ROOMS, rooms);
	}

	@Override
	public Room getRoom(Integer roomID){
		Room room = null;
		for(Room rm : getAllRooms() ) {
			if (rm.getRoomId() == roomID) {
				room = rm;
				break;
			}
		}
		return room;
	}

	@Override
	public Room[] getAllUnReservedRooms(LocalDate checkInDate, LocalDate checkOutDate) {
		Room[] result = null;

		if (checkInDate != null || checkOutDate != null) {
			ReservationDao reservationDao = new ReservationDaoImpl();
			List<Reservation> reservations = reservationDao.getAllReservations(false);
			List<Room> allRooms = new ArrayList<Room>(Arrays.asList(getAllRooms()));
			allRooms = allRooms.stream().filter(x -> x.getBeds().size() > 0).collect(Collectors.toList());
			allRooms = allRooms.stream().filter(x -> x.getStatus() == RoomStatus.AVAILABLE).collect(Collectors.toList());
			
			for (Reservation reservation : reservations) {
				if (checkInDate.isBefore(DateUtil.convertDateToLocalDate(reservation.getCheckOutDate()))) {

					Room reservedRoom = null;

					for (Room room : allRooms) {
						if (room.getRoomId() == reservation.getRoom().getRoomId()) {
							reservedRoom = room;
							break;
						}
					}

					if (reservedRoom != null) {
						if (!reservedRoom.isRoomAvailable())
							allRooms.remove(reservedRoom);
					}
				}
			}
			result = allRooms.toArray(new Room[] {});
		} else {
			result = getAllRooms();
		}
		return result;
	}

	@Override
	public String[] getAvailableBeds(Integer roomID) {
		Room room = getRoom(roomID);
		if (room != null) {
			List<Bed> beds = room.getBeds();
			beds = beds.stream().filter(x -> x.getBedStatus().equals(BedStatus.AVAILABLE)).collect(Collectors.toList());
			List<String> bedNumbers = beds.stream().map(x -> x.getBedId() + " - " + x.getBedType()).collect(Collectors.toList());
			return bedNumbers.toArray(new String[] {});
		}
		return new String[] {};
	}

	@Override
	public Room bookBed(int roomID, int bedId) {
		Room room = getRoom(roomID);
		if (room != null) {
			List<Bed> beds = room.getBeds();
			int noOfBookedBeds = 0;

			for (Bed bed : beds) {
				if (bed.getBedStatus() == BedStatus.BOOKED) {
					noOfBookedBeds++;
				}

				if (bed.getId() == bedId) {
					bed.setBedStatus(BedStatus.BOOKED);
					noOfBookedBeds++;
				}
			}

			if (beds.size() == noOfBookedBeds)
				room.setStatus(RoomStatus.BOOKED);

			room.setBeds(beds);
			saveRoom(room);
		}
		return room;
	}

	@Override
	public Room performCheckOut(int roomID, String bedIds) {
		Room room = getRoom(roomID);
		if (room != null) {
			if (room instanceof SingleRoom || room instanceof DoubleRoom) {
				List<Bed> beds = room.getBeds();
				for (Bed bed : beds) {
					bed.setBedStatus(BedStatus.AVAILABLE);
				}
				room.setStatus(RoomStatus.AVAILABLE);
				room.setBeds(beds);
			} else {
				String[] bedItems = bedIds.split(",");
				List<Bed> beds = room.getBeds();
				int noOfBookedBeds = 0;

				for (Bed bed : beds) {
					for (String bedItem : bedItems) {
						if (bed.getId() == Integer.valueOf(bedItem)) {
							bed.setBedStatus(BedStatus.AVAILABLE);
							break;
						}
					}

					if (bed.getBedStatus() == BedStatus.BOOKED) {
						noOfBookedBeds++;
					}
				}

				if (noOfBookedBeds < beds.size())
					room.setStatus(RoomStatus.AVAILABLE);

				room.setBeds(beds);
			}
			saveRoom(room);
		}
		return room;
	}

	@Override
	public Room bookRoom(int roomID) {
		Room room = getRoom(roomID);
		if (room != null) {
			List<Bed> beds = room.getBeds();
			for (Bed bed : beds) {
				bed.setBedStatus(BedStatus.BOOKED);
			}
			room.setStatus(RoomStatus.BOOKED);
			room.setBeds(beds);

			saveRoom(room);
		}
		return room;
	}

	@Override
	public Room deleteRoom(int roomId) {
		HashMap<Integer, Room> rooms = readRoomsMap();
		Room room = rooms.remove(roomId);
		Storage.saveToStorage(StorageType.ROOMS, rooms);
		return room;
	}

	@Override
	public boolean removeBedFromRoom(int roomID, int bedId) {
		Room room = getRoom(roomID);
		if (room != null) {
			List<Bed> beds = room.getBeds();
			beds = beds.stream().filter(x -> x.getId() != bedId).collect(Collectors.toList());
			room.setBeds(beds);
			saveRoom(room);
		}
		if (room == null)
			return false;

		return true;
	}

	@Override
	public boolean updateRoom(int roomId, String description, int maxNoOfBeds, double dailyRate) throws TooManyBedsException {
		boolean result = false;
		Room room = getRoom(roomId);
		if (room != null) {
			if (room instanceof SingleRoom) {
				if (maxNoOfBeds > 1) 
					throw new TooManyBedsException();
				room.setDescription(description);
				room.setMaxNoOfBeds(maxNoOfBeds);
				((SingleRoom) room).setDailyRate(dailyRate);
			} else if (room instanceof DoubleRoom) {
				if (maxNoOfBeds > 2) 
					throw new TooManyBedsException();
				room.setDescription(description);
				room.setMaxNoOfBeds(maxNoOfBeds);
				((DoubleRoom) room).setDailyRate(dailyRate);
			} else if (room instanceof DormRoom) {
				room.setDescription(description);
				room.setMaxNoOfBeds(maxNoOfBeds);
			}
			result = true;
			saveRoom(room);
		}
		return result;
	}

	@Override
	public boolean updateBed(int roomId, int bedId, BedType bedType, double dailyRate) throws WrongBedTypeException {
		boolean result = false;
		Room room = getRoom(roomId);
		if (room != null) {
			List<Bed> beds = room.getBeds();

			for (Bed bed : beds) {
				if (bed.getId() == bedId) {
					if (room instanceof SingleRoom) {
						if (bedType == BedType.LOWER || bedType == BedType.DOUBLE || bedType == BedType.UPPER) {
							throw new WrongBedTypeException("Only single beds are allowed in single rooms");
						}
					}

					if (room instanceof DoubleRoom) {
						if (bedType == BedType.LOWER || bedType == BedType.UPPER) {
							throw new WrongBedTypeException("Only single or double beds are allowed in double rooms");
						}
					}

					if (room instanceof DormRoom) {
						bed.setDailyRate(dailyRate);
					}
					
					bed.setBedType(bedType);
					break;
				}
			}

			room.setBeds(beds);
			saveRoom(room);
			result = true;
		}
		return result;
	}
}