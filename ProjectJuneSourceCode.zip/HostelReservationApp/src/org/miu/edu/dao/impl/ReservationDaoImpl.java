package org.miu.edu.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.miu.edu.dao.ReservationDao;
import org.miu.edu.dao.impl.Storage.StorageType;
import org.miu.edu.model.Reservation;
import org.miu.edu.model.ReservationStatus;
import org.miu.edu.model.UserType;
import org.miu.edu.util.UserUtil;

public class ReservationDaoImpl implements ReservationDao {

	@SuppressWarnings("unchecked")
	@Override
	public HashMap<Integer, Reservation> readReservationsMap() {
		Object o = Storage.readFromStorage(StorageType.RESERVATIONS);
		if (o == null)
			return new HashMap<Integer, Reservation>();
		return (HashMap<Integer, Reservation>)o ;
	}

	public void updateReservation(Reservation reservation) {
		HashMap<Integer, Reservation> reservations = readReservationsMap();
		reservations.put(reservation.getReservationId(), reservation);
		Storage.saveToStorage(StorageType.RESERVATIONS, reservations);
	}

	@Override
	public Reservation cancelReservation(int reservationId) {		
		Reservation reservation = getReservation(reservationId);
		reservation.setReservationStatus(ReservationStatus.CANCELLED);
		updateReservation(reservation);
		return reservation;
	}
	
	@Override
	public Reservation performCheckOut(int reservationId) {		
		Reservation reservation = getReservation(reservationId);
		reservation.setReservationStatus(ReservationStatus.CHECKED_OUT);
		updateReservation(reservation);
		return reservation;
	}

	@Override
	public void saveNewReservation(Reservation reservation) {
		HashMap<Integer, Reservation> reservations = readReservationsMap();
		reservation.setReservationId(reservations.size() + 1);
		reservations.put(reservation.getReservationId(), reservation);
		Storage.saveToStorage(StorageType.RESERVATIONS, reservations);
	}
	@Override
	public List<Reservation> getAllReservations(boolean doFiltering) {
		HashMap<Integer, Reservation> reservationsMap = readReservationsMap();
		List<Reservation> reservations = new ArrayList<Reservation>(reservationsMap.values());

		/*
		 *  filtered reservations for Logged on user who is not admin
		 */
		if (doFiltering) {
			if (UserUtil.getLoggedInUser().getUserType() != UserType.BOTH) {
				reservations = reservations.stream().filter(x -> x.getUser().getId() == UserUtil.getLoggedInUser().getId()).collect(Collectors.toList());
			}
		}
		return reservations;
	}

	@Override
	public Reservation getReservation(int reservationId) {
		Reservation reservation = null;
		for(Reservation reservation1 : getAllReservations(false)) {
			if (reservation1.getReservationId() == reservationId) {
				reservation = reservation1;
				break;
			}
		}
		return reservation;
	}
}