package org.miu.edu.dao.impl;

import java.util.HashMap;

import org.miu.edu.dao.UserDao;
import org.miu.edu.dao.impl.Storage.StorageType;
import org.miu.edu.model.User;

public class UserDaoImpl implements UserDao {

	@SuppressWarnings("unchecked")
	public HashMap<Integer, User> readUsersMap() {
		Object o = Storage.readFromStorage(StorageType.USERS);
		if (o == null) 
			return new HashMap<Integer, User>();

		return(HashMap<Integer, User>)o;
	}

	@Override
	public void updateUser(User user) {
		HashMap<Integer, User> users = readUsersMap();
		users.put(user.getId(), user);
		Storage.saveToStorage(StorageType.USERS, users);
	}

	@Override
	public void saveNewUser(User user) {
		HashMap<Integer, User> users = readUsersMap();
		user.setId(users.size() + 1);
		users.put(user.getId(), user);
		Storage.saveToStorage(StorageType.USERS, users);
	}

	@Override
	public User authenticateUser(String emailAddress, String password) {
		User[] users = getAllUsers();
		User loggedUser = null;
		
		for (User user : users) {
			if (user.getEmailAddress().equalsIgnoreCase(emailAddress) 
					&& user.getPassword().equals(password)) {
				loggedUser = user;
			}
		}	
		return loggedUser;
	}

	@Override
	public User[] getAllUsers() {
		HashMap<Integer, User> users = readUsersMap();
		return users.values().toArray(new User[] {});
	}

	@Override
	public void removeAllUsers() {
		HashMap<Integer, User> users = new HashMap<Integer, User>();
		Storage.saveToStorage(StorageType.USERS, users);
	}
}