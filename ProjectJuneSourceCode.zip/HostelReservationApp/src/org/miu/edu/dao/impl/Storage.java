package org.miu.edu.dao.impl;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;

public class Storage {
	
	public static final String OUTPUT_DIR = "src/org/miu/edu/storage/";
	
	static enum StorageType {
		ROOMS, USERS, RESERVATIONS;
	}

	static void saveToStorage(StorageType type, Object ob)
	{
		ObjectOutputStream out = null;
		try
		{
			Path path = FileSystems.getDefault().getPath(OUTPUT_DIR, type.toString());
			out = new ObjectOutputStream(Files.newOutputStream(path));
			out.writeObject(ob);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if (out != null)
			{
				try
				{
					out.close();
				}
				catch (Exception e)
				{
				}
			}
		}
	}

	static Object readFromStorage(StorageType type)
	{
		ObjectInputStream in = null;
		Object retVal = null;
		try
		{
			Path path = FileSystems.getDefault().getPath(OUTPUT_DIR, type.toString());
			in = new ObjectInputStream(Files.newInputStream(path));
			retVal = in.readObject();
		}
		catch (IOException e)
		{
			//e.printStackTrace();
			return null;
		}
		catch (Exception e)
		{
			return null;
		}
		finally
		{ 
			if (in != null)
			{
				try
				{
					in.close();
				}
				catch (Exception e)
				{
				}
			}
		}
		return retVal;
	}
}