package org.miu.edu;

import org.miu.edu.util.UserUtil;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
 
public class MainWindow extends Application {
	
    public static void main(String[] args) {
        launch(args);
    }
    
    @Override
    public void start(Stage primaryStage) {
    	try {
    		//UserUtil.removeAllUsers();//Clear user database
    		UserUtil.loadTestUsers();// Load test users
    		
            Parent root = FXMLLoader.load(getClass().getResource("/org/miu/edu/views/Login.fxml"));
            primaryStage.setScene(new Scene(root));
            primaryStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}