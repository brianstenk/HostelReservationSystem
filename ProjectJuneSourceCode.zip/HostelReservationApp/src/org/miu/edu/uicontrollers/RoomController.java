package org.miu.edu.uicontrollers;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import org.miu.edu.dao.RoomDao;
import org.miu.edu.dao.impl.RoomDaoImpl;
import org.miu.edu.exceptions.TooManyBedsException;
import org.miu.edu.model.DormRoom;
import org.miu.edu.model.DoubleRoom;
import org.miu.edu.model.Room;
import org.miu.edu.model.RoomStatus;
import org.miu.edu.model.RoomType;
import org.miu.edu.model.SingleRoom;
import org.miu.edu.model.UserType;
import org.miu.edu.model.dto.RoomDTO;
import org.miu.edu.util.WindowUtil;
import org.miu.edu.util.UserUtil;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

public class RoomController implements Initializable {

	@FXML
	private Button btnBack;

	@FXML
	private Button btnAdd;

	@FXML
	private TextField txtRoomId;

	@FXML
	private Text addEditRoom;

	@FXML
	private CheckBox checkBoxSingleRoom;

	@FXML
	private CheckBox chechboxdoubleRoom;

	@FXML
	private CheckBox checkBoxDormRoom;

	@FXML
	private TextField txtNumberOfBeds;

	@FXML
	private TextField txtDailyRate;

	@FXML
	private TextArea txtDescription;

	private RoomDao roomDao;

	private boolean isUpdate = false;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		roomDao = new RoomDaoImpl();
	}

	public void addUpdateRoom(ActionEvent event) {
		if (isUpdate) {
			try {
				if(roomDao.updateRoom(Integer.valueOf(txtRoomId.getText()), txtDescription.getText(), Integer.valueOf(txtNumberOfBeds.getText()), 
								Double.valueOf(txtDailyRate.getText()))) {
					Alert alert = WindowUtil.createAlert("Room Update", "Room No. " + txtRoomId.getText() + " has been updated successfully !!!", AlertType.INFORMATION);
					Optional<ButtonType> result = alert.showAndWait();
					if (result.get() == ButtonType.OK){
						WindowUtil.loadWindow("ViewAllRooms", event, this.getClass());
					}
				} else {
					WindowUtil.createAlert("Room Update", "Room update request failed !!!", AlertType.ERROR).showAndWait();
				}
			} catch (NumberFormatException e) {
				WindowUtil.createAlert("Room Update", "Please input number values !!!", AlertType.ERROR).showAndWait();
			} catch (TooManyBedsException e) {
				WindowUtil.createAlert("Room Update", "Too many beds error !!!", AlertType.ERROR).showAndWait();
			}
		} else {		
			Room room = null;
			if (txtRoomId.getText().isEmpty()) {
				WindowUtil.createAlert("Add Room", "Please specify room ID !!!", AlertType.ERROR).showAndWait();
			} else if (txtNumberOfBeds.getText().isEmpty()) {
				WindowUtil.createAlert("Add Room", "Please specify no. of beds in room !!!", AlertType.ERROR).showAndWait();
			} else if (txtDescription.getText().isEmpty()) {
				WindowUtil.createAlert("Add Room", "Please specify description !!!", AlertType.ERROR).showAndWait();
			} else {
				if (checkBoxSingleRoom.isSelected()) {
					if (Double.valueOf(txtNumberOfBeds.getText()) > 1) {
						WindowUtil.createAlert("Add Room", "Maximum number of beds is 1 in single room !!!", AlertType.ERROR).showAndWait();
						return;
					}
					
					if (txtDailyRate.getText().isEmpty()) {
						WindowUtil.createAlert("Add Room", "Please specify daily rate !!!", AlertType.ERROR).showAndWait();
						return;
					} 

					room = new SingleRoom(RoomStatus.AVAILABLE, txtDescription.getText(), Integer.valueOf(txtNumberOfBeds.getText()), 
							Double.valueOf(txtDailyRate.getText()), Integer.valueOf(txtRoomId.getText()));
				} else if (chechboxdoubleRoom.isSelected()) {
					if (Double.valueOf(txtNumberOfBeds.getText()) > 2) {
						WindowUtil.createAlert("Add Room", "Maximum number of beds is 2 in double room !!!", AlertType.ERROR).showAndWait();
						return;
					}
					
					if (txtDailyRate.getText().isEmpty()) {
						WindowUtil.createAlert("Add Room", "Please specify daily rate !!!", AlertType.ERROR).showAndWait();
						return;
					} 

					room = new DoubleRoom(RoomStatus.AVAILABLE, txtDescription.getText(), Integer.valueOf(txtNumberOfBeds.getText()), 
							Double.valueOf(txtDailyRate.getText()), Integer.valueOf(txtRoomId.getText()));
				} else if (checkBoxDormRoom.isSelected()) {
					room = new DormRoom(RoomStatus.AVAILABLE, txtDescription.getText(), Integer.valueOf(txtNumberOfBeds.getText()), 
							Integer.valueOf(txtRoomId.getText()));
				}

				if (room != null) {
					roomDao.saveNewRoom(room);
					clearFields();
					WindowUtil.createAlert("Add Room", "Room has been added successfully", AlertType.INFORMATION).showAndWait();
				} else {
					WindowUtil.createAlert("Add Room", "Please select room type !!!", AlertType.ERROR).showAndWait();
				}
			}
		}
	}

	public void editRoom(RoomDTO room) {
		addEditRoom.setText("Edit Room");
		btnAdd.setText("Update");
		isUpdate = true;
		txtRoomId.setText(String.valueOf(room.getRoomId()));
		txtNumberOfBeds.setText(String.valueOf(room.getMaxNoOfBeds()));
		txtDescription.setText(room.getDescription());

		if (room.getRoomType() == RoomType.DOUBLE) {
			chechboxdoubleRoom.setSelected(true);
			txtDailyRate.setText(String.valueOf(room.getDailyRate()));
		} else if (room.getRoomType() == RoomType.SINGLE) {
			checkBoxSingleRoom.setSelected(true);
			txtDailyRate.setText(String.valueOf(room.getDailyRate()));
		} else if (room.getRoomType() == RoomType.DORM) {
			checkBoxDormRoom.setSelected(true);
			txtDailyRate.setDisable(true);
		}
		chechboxdoubleRoom.setDisable(true);
		checkBoxSingleRoom.setDisable(true);
		checkBoxDormRoom.setDisable(true);
		txtRoomId.setDisable(true);
	}

	private void clearFields() {
		txtRoomId.setText("");
		txtNumberOfBeds.setText("");
		txtDailyRate.setText("");
		txtDescription.setText("");
		checkBoxSingleRoom.setSelected(false);
		checkBoxDormRoom.setSelected(false);
		chechboxdoubleRoom.setSelected(false);
	}

	public void back(ActionEvent event) {
		if (isUpdate) {
			WindowUtil.loadWindow("ViewAllRooms", event, this.getClass());
		} else {
			if (UserUtil.getLoggedInUser().getUserType() == UserType.BOTH)
				WindowUtil.loadWindow("BothRole", event, this.getClass());
			else if (UserUtil.getLoggedInUser().getUserType() == UserType.ADMIN)
				WindowUtil.loadWindow("Admin", event, this.getClass());
		}
	}

	@FXML
	private void handleCheckBoxRoomType(ActionEvent event) {
		CheckBox checkBox = (CheckBox) event.getSource();

		if(checkBoxSingleRoom.isSelected() && checkBox.getId().equalsIgnoreCase("checkBoxSingleRoom")) {
			chechboxdoubleRoom.setSelected(false);
			checkBoxDormRoom.setSelected(false);
			txtDailyRate.setDisable(false);
		} 

		if(chechboxdoubleRoom.isSelected() && checkBox.getId().equalsIgnoreCase("chechboxdoubleRoom")) {
			checkBoxSingleRoom.setSelected(false);
			checkBoxDormRoom.setSelected(false);
			txtDailyRate.setDisable(false);
		} 

		if(checkBoxDormRoom.isSelected() && checkBox.getId().equalsIgnoreCase("checkBoxDormRoom")) {
			checkBoxSingleRoom.setSelected(false);
			chechboxdoubleRoom.setSelected(false);
			txtDailyRate.setDisable(true);
		}
	}
}