package org.miu.edu.uicontrollers;

import java.net.URL;
import java.util.ResourceBundle;

import org.miu.edu.util.WindowUtil;
import org.miu.edu.util.UserUtil;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

public class UserContoller implements Initializable{
	
	@FXML
	private Button btnSeeReservation;
	
	@FXML
	private Button btnSearchAvailRooms;
	
	@FXML
	private Button btnExit;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}
	
	public void onSearchRooms(ActionEvent event) {
		WindowUtil.loadWindow("SearchAvailableRoom", event, this.getClass());
	}
	public void onSeeReservation(ActionEvent event) {
		WindowUtil.loadWindow("ViewAllReservations", event, this.getClass());
	}
	
	public void exit(ActionEvent event) {
		UserUtil.setLoggedInUser(null);
		WindowUtil.loadWindow("Login", event, this.getClass());
	}
}