package org.miu.edu.uicontrollers;


import java.net.URL;
import java.util.ResourceBundle;
import org.miu.edu.model.Room;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class ReserveAvailableRoomController implements Initializable {

	@FXML
	private Button exitReserveRoom;

	// needs to change
	ObservableList<Room> reservationsData = FXCollections.observableArrayList();

	@FXML
	private TableView<Room> tblSearchAvailRooms;

	@FXML
	private TableColumn<Room, Integer> reserBedRmNo;

	@FXML
	private TableColumn<Room, String> eseveType;

	@FXML
	private TableColumn<Room, Integer> reservDescript;

	@FXML
	private TableColumn<Room, Double> reserRate;

	@FXML 
	private TableColumn<Room, String> reserStatuss;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub

	}

	public void filter(ActionEvent event) {
		//Search according to the filter dates
		//AppWindowController.loadWindow("ListBeds", event, this.getClass());


	}

	public void reserve(ActionEvent event) {
		//Search according to the filter dates
		//AppWindowController.loadWindow("B", event, this.getClass());


	}

	//loadPreviousList
	public void exit(ActionEvent event) {

		System.out.println("Application Exit!");

		System.exit(0);

	}
}