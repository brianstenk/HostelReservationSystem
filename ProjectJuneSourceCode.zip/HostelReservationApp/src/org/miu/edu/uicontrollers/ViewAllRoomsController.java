package org.miu.edu.uicontrollers;


import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import org.miu.edu.dao.RoomDao;
import org.miu.edu.dao.impl.RoomDaoImpl;
import org.miu.edu.model.Room;
import org.miu.edu.model.UserType;
import org.miu.edu.model.dto.RoomDTO;
import org.miu.edu.util.WindowUtil;
import org.miu.edu.util.UserUtil;

import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

public class ViewAllRoomsController implements Initializable {

	@FXML
	private Button btnBackViewAllRooms;
	
	@FXML
	private Button btnAddBed;

	@FXML
	private Button btnListBeds;
	
	@FXML
	private Button btnEditRoom;
	
	@FXML
	private Button btnDeleteRoom;

	ObservableList<RoomDTO> roomsData = FXCollections.observableArrayList();

	@FXML
	private TableView<RoomDTO> tblViewAllRooms;

	@FXML
	private  TableColumn<RoomDTO, String> clmRoomId;

	@FXML
	private TableColumn<RoomDTO, String> clmRoomType;

	@FXML
	private TableColumn<RoomDTO, Integer> clmMaxOfBeds;

	@FXML
	private TableColumn<RoomDTO, Double> clmDailyRate;

	@FXML
	private TableColumn<RoomDTO, String> clmDescription;

	@FXML
	private TableColumn<RoomDTO, Integer> clmNumOfBeds;

	@FXML
	private TableColumn<RoomDTO, String> clmRoomStatus;

	private RoomDao roomDao;

	RoomDTO selectedRoom;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		roomDao = new RoomDaoImpl();
		clmRoomId.setCellValueFactory(new PropertyValueFactory<RoomDTO, String>("roomId"));
		clmRoomType.setCellValueFactory(new PropertyValueFactory<RoomDTO, String>("roomType"));
		clmMaxOfBeds.setCellValueFactory(new PropertyValueFactory<RoomDTO, Integer>("maxNoOfBeds"));
		clmDailyRate.setCellValueFactory(new PropertyValueFactory<RoomDTO, Double>("dailyRate"));
		clmDescription.setCellValueFactory(new PropertyValueFactory<RoomDTO, String>("description"));
		clmNumOfBeds.setCellValueFactory(new PropertyValueFactory<RoomDTO, Integer>("noOfBeds"));
		clmRoomStatus.setCellValueFactory(new PropertyValueFactory<RoomDTO, String>("roomStatus"));

		this.getAllRooms();
		loadRoomData(roomsData);

		btnAddBed.setDisable(true);
		btnListBeds.setDisable(true);
		
		btnEditRoom.setDisable(true);
		btnDeleteRoom.setDisable(true);
	}

	public void onClickBack(ActionEvent event) {
		if (UserUtil.getLoggedInUser().getUserType() == UserType.BOTH)
			WindowUtil.loadWindow("BothRole", event, this.getClass());
		else if (UserUtil.getLoggedInUser().getUserType() == UserType.ADMIN)
			WindowUtil.loadWindow("Admin", event, this.getClass());
	}

	public void AddBed(ActionEvent event) {
		WindowUtil.loadWindow("AddEditBed", event, this.getClass());
	}

	public void listBed(ActionEvent event) {
		WindowUtil.loadWindow("ViewAllBeds", event, this.getClass());
	}

	public ObservableList<RoomDTO> getRoomsData() {
		return roomsData;
	}

	private void loadRoomData(ObservableList<RoomDTO> roomsData2) {
		tblViewAllRooms.setItems(getRoomsData());

		tblViewAllRooms.setRowFactory(tv -> {
			TableRow<RoomDTO> row = new TableRow<>();
			row.setOnMouseClicked(event -> {
				if (event.getClickCount() == 1 && (!row.isEmpty())) {
					selectedRoom = row.getItem();
					btnAddBed.setDisable(false);
					btnListBeds.setDisable(false);
					
					btnEditRoom.setDisable(false);
					btnDeleteRoom.setDisable(false);
				}
			});
			return row;
		});
	}

	private void getAllRooms() {
		Room[] rooms = roomDao.getAllRooms();
		for (Room room : rooms)
			roomsData.add(new RoomDTO(room));
	}
	
	public void onEditRoom(ActionEvent event) {
		if (selectedRoom != null) {
			FXMLLoader loader = WindowUtil.loadWindow("AddEditRoom", event, this.getClass());
			RoomController controller = loader.getController();
			if (selectedRoom != null) {
				controller.editRoom(selectedRoom);
			}
		}
	}
	
	public void onDeleteRoom(ActionEvent event) {
		if (selectedRoom != null) {
			Alert alert = WindowUtil.createAlert("Delete Room", "Are you sure you want to delete room ?", AlertType.CONFIRMATION);
			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.OK){
				if (roomDao.deleteRoom(selectedRoom.getRoomId()) != null) {
					roomsData.remove(selectedRoom);
					btnListBeds.setDisable(true);
					btnEditRoom.setDisable(true);
					btnDeleteRoom.setDisable(true);
					btnAddBed.setDisable(true);
					selectedRoom = null;
					tblViewAllRooms.refresh();
					WindowUtil.createAlert("Delete Room", "Room Deleted Successfully", AlertType.INFORMATION).showAndWait();
				}
			}
		}
	}

	public void onAddBed(ActionEvent event) {
		FXMLLoader loader = WindowUtil.loadWindow("AddEditBed", event, this.getClass());
		BedController controller = loader.getController();
		if (selectedRoom != null) {
			controller.setRoomId(selectedRoom.getRoomId());
			controller.setRoomType(selectedRoom.getRoomType());
		}
	}

	//onListOfBed
	public void onListOfBed(ActionEvent event) {
		FXMLLoader loader = WindowUtil.loadWindow("ViewAllBeds", event, this.getClass());

		ViewAllBedsController controller = loader.getController();
		if (selectedRoom != null) {
			controller.setRoomDetails(selectedRoom.getRoomId(), selectedRoom.getRoomType());
		}
	}
}