package org.miu.edu.uicontrollers;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import org.miu.edu.dao.UserDao;
import org.miu.edu.dao.impl.UserDaoImpl;
import org.miu.edu.model.User;
import org.miu.edu.model.UserType;
import org.miu.edu.util.WindowUtil;
import org.miu.edu.util.UserUtil;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;

public class LoginController implements Initializable {

	@FXML
	private TextField txtEmailAddress;

	@FXML
	private TextField txtPassword;

	private UserDao userDao;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		userDao = new UserDaoImpl(); 
	}

	public void onLogIn(ActionEvent event) {
		String emailAddress = txtEmailAddress.getText();
		String password = txtPassword.getText();

		User user = userDao.authenticateUser(emailAddress, password);

		if (user != null) {
			UserUtil.setLoggedInUser(user);//Saved logged in user

			if (user.getUserType().equals(UserType.ADMIN)) {
				WindowUtil.loadWindow("Admin", event, this.getClass());
			} else if (user.getUserType().equals(UserType.BOTH)) {
				WindowUtil.loadWindow("BothRole", event, this.getClass());
			} else {
				WindowUtil.loadWindow("User", event, this.getClass());
			}
		} else {
			WindowUtil.createAlert("Login", "Invalid Username or Password", AlertType.ERROR).showAndWait();
		}
	}

	public void onAddUser(ActionEvent event) {
		WindowUtil.loadWindow("Register", event, this.getClass());
	}
	
	public void onBackButton(ActionEvent event) {
		WindowUtil.loadWindow("Login", event, this.getClass());
	}

	public void onRegister(ActionEvent event) {
		String emailAddress = txtEmailAddress.getText();
		String password = txtPassword.getText();

		if (emailAddress.isEmpty()) {
			WindowUtil.createAlert("Account Creation", "Please specify email address !!!", AlertType.ERROR).showAndWait();
		} else if (password.isEmpty()) {
			WindowUtil.createAlert("Account Creation", "Please specify user password !!!", AlertType.ERROR).showAndWait();
		} else {
			User otherUser = new User(emailAddress, UserType.USER, password);
			userDao.saveNewUser(otherUser);

			Alert alert = WindowUtil.createAlert("Account Creation", "Account created successfully", AlertType.INFORMATION);
			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.OK){
				WindowUtil.loadWindow("Login", event, this.getClass());
			}
		}
	}
}