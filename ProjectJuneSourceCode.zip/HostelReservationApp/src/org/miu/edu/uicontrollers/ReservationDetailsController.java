package org.miu.edu.uicontrollers;

import java.net.URL;
import java.util.ResourceBundle;

import org.miu.edu.util.WindowUtil;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ReservationDetailsController implements Initializable {

	@FXML
	private Label lblFirstName;
	
	@FXML
	private Label lblAddress;
	
	@FXML
	private Label lblCheckInDate;
	
	@FXML
	private Label lblPeronId;
	
	@FXML
	private Label lblLastName;
	
	@FXML
	private Label lblPhone;
	
	@FXML
	private Label lblCheckOutDate;
	
	@FXML
	private Label lblBedNumber;
	
	@FXML
	private Button btnBack;

	@FXML
	private Button btnCancel;

	// backToListOfReservation
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
	}

	public void cancelReservation(ActionEvent event) {
		WindowUtil.loadWindow("#", event, this.getClass());
	}
	
	public void backToListOfReservation(ActionEvent event) {
		WindowUtil.loadWindow("User", event, this.getClass());
	}
}