package org.miu.edu.uicontrollers;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import org.miu.edu.dao.RoomDao;
import org.miu.edu.dao.impl.RoomDaoImpl;
import org.miu.edu.model.Bed;
import org.miu.edu.model.Room;
import org.miu.edu.model.RoomType;
import org.miu.edu.util.WindowUtil;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

public class ViewAllBedsController implements Initializable {

	@FXML
	private Button btnBackViewAllBeds;

	@FXML
	private Button deleteBed;

	@FXML
	private Button btnEditBed;

	ObservableList<Bed> bedsData = FXCollections.observableArrayList();

	@FXML
	private TableView<Bed> tblViewAllBeds;

	@FXML
	private  TableColumn<Bed, Integer> clmBedId;

	@FXML
	private  TableColumn<Bed, Double> clmDailyRate;

	@FXML
	private  TableColumn<Bed, String> clmBedType;

	@FXML
	private  TableColumn<Bed, String> clmBedStatus;

	@FXML
	private Label lbRoomId;
	
	@FXML
	private Label lblRoomType;

	private RoomDao roomDao;

	private Bed selectedBed;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		roomDao = new RoomDaoImpl();
		clmBedId.setCellValueFactory(new PropertyValueFactory<Bed, Integer>("id"));
		clmDailyRate.setCellValueFactory(new PropertyValueFactory<Bed, Double>("dailyRate"));
		clmBedType.setCellValueFactory(new PropertyValueFactory<Bed, String>("bedType"));	
		clmBedStatus.setCellValueFactory(new PropertyValueFactory<Bed, String>("bedStatus"));	

		deleteBed.setDisable(true);
		btnEditBed.setDisable(true);
	}

	public void setRoomDetails(int roomId, RoomType roomType) {
		lbRoomId.setText(String.valueOf(roomId));
		lbRoomId.setVisible(false);

		lblRoomType.setText(roomType.name());
		lblRoomType.setVisible(false);
		
		this.getAllBeds();
		loadBedData(bedsData);
	}

	private void loadBedData(ObservableList<Bed> roomsData2) {
		tblViewAllBeds.setItems(bedsData);
		tblViewAllBeds.setRowFactory(tv -> {
			TableRow<Bed> row = new TableRow<>();
			row.setOnMouseClicked(event -> {
				if (event.getClickCount() == 1 && (!row.isEmpty())) {
					selectedBed = row.getItem();
					deleteBed.setDisable(false);
					btnEditBed.setDisable(false);
				}
			});
			return row;
		});
	}

	public void onDeleteBed(ActionEvent event) {
		if (selectedBed != null) {
			Alert alert = WindowUtil.createAlert("Delete Bed", "Are you sure you want to delete bed ?", AlertType.CONFIRMATION);
			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.OK){
				int roomId = Integer.valueOf(lbRoomId.getText());
				if (roomDao.removeBedFromRoom(roomId, selectedBed.getId())); {
					bedsData.remove(selectedBed);
					loadBedData(bedsData);
					WindowUtil.createAlert("Delete Bed", "Bed Deleted Successfully", AlertType.INFORMATION).showAndWait();
				}
			}
		}
	}

	public void onEditBed(ActionEvent event) {
		if (selectedBed != null) {
			FXMLLoader loader = WindowUtil.loadWindow("AddEditBed", event, this.getClass());
			BedController controller = loader.getController();
			if (selectedBed != null) {
				controller.editBed(selectedBed, RoomType.valueOf(lblRoomType.getText()), Integer.valueOf(lbRoomId.getText()));
			}
		}
	}

	private void getAllBeds() {
		int roomId = Integer.valueOf(lbRoomId.getText());
		Room room = roomDao.getRoom(roomId);
		bedsData.addAll(room.getBeds());
	}

	public void goBackHome(ActionEvent event) {
		WindowUtil.loadWindow("ViewAllRooms", event, this.getClass());
	}
}