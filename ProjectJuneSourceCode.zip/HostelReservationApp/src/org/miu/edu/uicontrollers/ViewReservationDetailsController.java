package org.miu.edu.uicontrollers;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ViewReservationDetailsController implements Initializable {
	
	@FXML
	private Label lblFirstName;
	
	@FXML
	private Label lblAddress;
	
	@FXML
	private Label lblCheckInDate;
	
	@FXML
	private Label lblPeronId;
	
	@FXML
	private Label lblLastName;
	
	@FXML
	private Label lblPhone;
	
	@FXML
	private Label lblCheckOutDate;
	
	@FXML
	private Label lblBedNumber;
	
	@FXML
	private Button btnCancel1;
	
	@FXML
	private Button btnBack2;
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub

	}

	public void btnCancel(ActionEvent event) {

		System.exit(0);

	}
	
	public void backToListOfReservation(ActionEvent event) {
		//Back to the List of Reservations
		
	}

}
