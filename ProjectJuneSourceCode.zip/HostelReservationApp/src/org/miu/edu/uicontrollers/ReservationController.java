package org.miu.edu.uicontrollers;

import java.net.URL;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;

import org.miu.edu.dao.ReservationDao;
import org.miu.edu.dao.RoomDao;
import org.miu.edu.dao.impl.ReservationDaoImpl;
import org.miu.edu.dao.impl.RoomDaoImpl;
import org.miu.edu.model.Guest;
import org.miu.edu.model.PaymentType;
import org.miu.edu.model.Reservation;
import org.miu.edu.model.ReservationStatus;
import org.miu.edu.model.Room;
import org.miu.edu.model.RoomType;
import org.miu.edu.model.UserType;
import org.miu.edu.util.WindowUtil;
import org.miu.edu.util.DateUtil;
import org.miu.edu.util.UserUtil;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class ReservationController implements Initializable {

	@FXML
	private TextField txtFirstName;

	@FXML
	private TextField txtLastName;

	@FXML
	private TextField txtAddress;

	@FXML
	private TextField txtPhoneNumber;

	@FXML
	private DatePicker txtCheckInDate;

	@FXML
	private DatePicker txtCheckOutDate;

	@FXML
	private TextField txtPersonId;

	@FXML
	private TextField txtRoomNumber;

	@FXML
	private ChoiceBox<String> drpBeds;

	@FXML
	private ChoiceBox<String> choiceBoxPayment;

	@FXML 
	private Button btnBackResn;

	@FXML 
	private Button btnAddReservation;

	private ReservationDao reservDao;

	private RoomDao roomDao;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		reservDao = new ReservationDaoImpl();
		roomDao = new RoomDaoImpl();

		String methods[] = { "CREDIT", "CASH"}; 
		choiceBoxPayment.setItems(FXCollections.observableArrayList(methods));
	}

	public void setRoomNumber(String roomNumber, RoomType roomType) {
		txtRoomNumber.setText(roomNumber);
		txtRoomNumber.setDisable(true);

		String[] availableBeds = roomDao.getAvailableBeds(Integer.valueOf(roomNumber));
		drpBeds.setItems(FXCollections.observableArrayList(availableBeds));

		if (roomType == RoomType.DOUBLE || roomType == RoomType.SINGLE)
			drpBeds.setDisable(true);
	}

	public void setReservationDates(LocalDate checkInDate, LocalDate checkOutDate) {
		txtCheckInDate.setValue(checkInDate);
		txtCheckOutDate.setValue(checkOutDate);
	}

	public void addNewReservation(ActionEvent event) {
		if (txtFirstName.getText().isEmpty()) {
			WindowUtil.createAlert("Add Reservation", "Please specify firstname !!!", AlertType.ERROR).showAndWait();
		} else if (txtLastName.getText().isEmpty()) {
			WindowUtil.createAlert("Add Reservation", "Please specify lastname !!!", AlertType.ERROR).showAndWait();
		} else if (txtPersonId.getText().isEmpty()) {
			WindowUtil.createAlert("Add Reservation", "Please specify person ID !!!", AlertType.ERROR).showAndWait();
		} else if (txtPhoneNumber.getText().isEmpty()) {
			WindowUtil.createAlert("Add Reservation", "Please specify phone number !!!", AlertType.ERROR).showAndWait();
		} else if (txtAddress.getText().isEmpty()) {
			WindowUtil.createAlert("Add Reservation", "Please specify address !!!", AlertType.ERROR).showAndWait();
		} else if (choiceBoxPayment.getValue() == null) {
			WindowUtil.createAlert("Add Reservation", "Please select payment method !!!", AlertType.ERROR).showAndWait();
		} else {
			Alert alert = WindowUtil.createAlert("Payment Confirm", "Please confirm if payment has been made !!!", AlertType.CONFIRMATION);
			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.OK){
				Room room = null;
				String summary = "";

				if (drpBeds.getValue() != null) {
					String[] bedDetails = drpBeds.getValue().split("-");
					int bedNumber = Integer.valueOf(bedDetails[0].trim());
					room = roomDao.bookBed(Integer.valueOf(txtRoomNumber.getText()), bedNumber);
					summary = txtRoomNumber.getText()  + "-" + bedNumber;
				} else {
					room = roomDao.bookRoom(Integer.valueOf(txtRoomNumber.getText()));
					if (room.getBedSummaryInfo() != null)
						summary = txtRoomNumber.getText()  + "-" + room.getBedSummaryInfo().trim();
					else
						summary = txtRoomNumber.getText();
				}

				if (room != null) {
					Guest guest = new Guest(txtAddress.getText(), txtFirstName.getText(), txtLastName.getText(), txtPhoneNumber.getText(), txtPersonId.getText());
					Reservation reservation = new Reservation(DateUtil.convertLocalDateToDate(txtCheckInDate.getValue()), 
							DateUtil.convertLocalDateToDate(txtCheckOutDate.getValue()), room, guest, PaymentType.valueOf(choiceBoxPayment.getValue()),
							ReservationStatus.ACTIVE, UserUtil.getLoggedInUser());

					if (reservation != null) {
						reservation.setSummary(summary);
						reservDao.saveNewReservation(reservation);
						WindowUtil.createAlert("Payment confirmed", "Reservation has been created successfully !!!", AlertType.INFORMATION).showAndWait();
						clearFields();
					}
				}
			} else {
				Alert alert1 = WindowUtil.createAlert("Cancel Booking", "Do you want to cancel booking ? !!!", AlertType.CONFIRMATION);
				Optional<ButtonType> result1 = alert1.showAndWait();
				if (result1.get() == ButtonType.OK){
					if (UserUtil.getLoggedInUser().getUserType() == UserType.BOTH)
						WindowUtil.loadWindow("BothRole", event, this.getClass());
					else if (UserUtil.getLoggedInUser().getUserType() == UserType.USER)
						WindowUtil.loadWindow("User", event, this.getClass());
				} 
			}
		}
	}

	private void clearFields() {
		txtFirstName.setText("");
		txtLastName.setText("");
		txtPersonId.setText("");
		txtPhoneNumber.setText("");
		txtAddress.setText("");

		choiceBoxPayment.setValue("");
		drpBeds.setValue("");
	}

	public void backOnBoth(ActionEvent event) {
		if (UserUtil.getLoggedInUser().getUserType() == UserType.BOTH)
			WindowUtil.loadWindow("BothRole", event, this.getClass());
		else if (UserUtil.getLoggedInUser().getUserType() == UserType.USER)
			WindowUtil.loadWindow("User", event, this.getClass());
	}
}