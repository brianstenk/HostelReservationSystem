package org.miu.edu.uicontrollers;

import java.net.URL;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;

import org.miu.edu.dao.RoomDao;
import org.miu.edu.dao.impl.RoomDaoImpl;
import org.miu.edu.model.Room;
import org.miu.edu.model.UserType;
import org.miu.edu.model.dto.RoomDTO;
import org.miu.edu.util.WindowUtil;
import org.miu.edu.util.DateUtil;
import org.miu.edu.util.UserUtil;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;


public class SearchAvailableRoomsController implements Initializable {

	@FXML
	private DatePicker txtCheckInDateSar;

	@FXML
	private DatePicker txtCheckOutDateSar;

	@FXML 
	private Button btnFilterSar;

	@FXML
	private Button btnReserveSar;

	@FXML
	private Button btnBackSar;

	// check for room details
	ObservableList<RoomDTO> roomsData = FXCollections.observableArrayList();

	@FXML
	private TableView<RoomDTO> tblViewAllRooms;

	@FXML
	private  TableColumn<RoomDTO, String> clmRoomId;

	@FXML
	private TableColumn<RoomDTO, String> clmRoomType;

	@FXML
	private TableColumn<RoomDTO, Integer> clmMaxOfBeds;

	@FXML
	private TableColumn<RoomDTO, Double> clmDailyRate;

	@FXML
	private TableColumn<RoomDTO, String> clmDescription;

	@FXML
	private TableColumn<RoomDTO, Integer> clmNumOfBeds;

	@FXML
	private TableColumn<RoomDTO, String> clmRoomStatus;

	private RoomDao roomDao;

	RoomDTO selectedRoom;
	
	boolean isFiltered = false;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		roomDao = new RoomDaoImpl();
		clmRoomId.setCellValueFactory(new PropertyValueFactory<RoomDTO, String>("roomId"));
		clmRoomType.setCellValueFactory(new PropertyValueFactory<RoomDTO, String>("roomType"));
		clmMaxOfBeds.setCellValueFactory(new PropertyValueFactory<RoomDTO, Integer>("maxNoOfBeds"));
		clmDailyRate.setCellValueFactory(new PropertyValueFactory<RoomDTO, Double>("dailyRate"));
		clmDescription.setCellValueFactory(new PropertyValueFactory<RoomDTO, String>("description"));
		clmNumOfBeds.setCellValueFactory(new PropertyValueFactory<RoomDTO, Integer>("noOfBeds"));
		clmRoomStatus.setCellValueFactory(new PropertyValueFactory<RoomDTO, String>("roomStatus"));

		this.getAllRooms();
		displayUnreservedRooms(roomsData);
		btnReserveSar.setDisable(true);
	}

	public ObservableList<RoomDTO> getRoomsData() {
		return roomsData;
	}

	private void displayUnreservedRooms(ObservableList<RoomDTO> roomsData2) {
		tblViewAllRooms.setItems(getRoomsData());

		tblViewAllRooms.setRowFactory(tv -> {
			TableRow<RoomDTO> row = new TableRow<>();
			row.setOnMouseClicked(event -> {
				if (event.getClickCount() == 1 && (!row.isEmpty())) {
					selectedRoom = row.getItem();
					if (isFiltered)
						btnReserveSar.setDisable(false);
				}
			});
			return row;
		});
	}

	private void getAllRooms() {
		Room[] rooms = roomDao.getAllUnReservedRooms(null, null);
		for (Room room : rooms)
			roomsData.add(new RoomDTO(room));
	}

	public void fetchAllRooms() {
		txtCheckInDateSar.setValue(null);
		txtCheckOutDateSar.setValue(null);
		loadRoomInfo(null, null);
		btnReserveSar.setDisable(true);
		isFiltered = false;
	}

	public void filterRooms(ActionEvent event) {
		LocalDate checkInDate = txtCheckInDateSar.getValue();
		LocalDate checkOutDate = txtCheckOutDateSar.getValue();

		if (checkInDate == null) {
			WindowUtil.createAlert("Add Reservation", "Please specify check in date !!!", AlertType.ERROR).showAndWait();
			return;
		}
		
		if (checkOutDate == null) {
			WindowUtil.createAlert("Add Reservation", "Please specify check out date !!!", AlertType.ERROR).showAndWait();
			return;
		}
		if (DateUtil.isBefore(DateUtil.convertLocalDateToDate(checkInDate), new Date())) {
			WindowUtil.createAlert("Add Reservation", "Please specify correct check in date !!!", AlertType.ERROR).showAndWait();
		} else {
			if (checkInDate != null && checkOutDate != null) {
				//Validate date
				loadRoomInfo(checkInDate, checkOutDate);
			} else {
				WindowUtil.createAlert("Reservations", "Please enter checkin and checkout dates !!!", AlertType.ERROR).showAndWait();
			}
		}
	}

	private void loadRoomInfo(LocalDate checkInDate, LocalDate checkOutDate) {
		Room[] rooms = roomDao.getAllUnReservedRooms(checkInDate, checkOutDate);
		roomsData.clear();

		for (Room room : rooms)
			roomsData.add(new RoomDTO(room));

		displayUnreservedRooms(roomsData);

		if (rooms.length == 0)
			btnReserveSar.setDisable(true);
		else 
			isFiltered = true;
	}

	public void createReservation(ActionEvent event) {
		FXMLLoader loader = WindowUtil.loadWindow("AddReservation", event, this.getClass());
		ReservationController addReservationController = loader.getController();
		addReservationController.setRoomNumber(String.valueOf(selectedRoom.getRoomId()), selectedRoom.getRoomType());
		addReservationController.setReservationDates(txtCheckInDateSar.getValue(), txtCheckOutDateSar.getValue());
	}

	public void loadMainScreen(ActionEvent event) {
		if (UserUtil.getLoggedInUser().getUserType() == UserType.BOTH)
			WindowUtil.loadWindow("BothRole", event, this.getClass());
		else if (UserUtil.getLoggedInUser().getUserType() == UserType.USER)
			WindowUtil.loadWindow("User", event, this.getClass());
	}
}