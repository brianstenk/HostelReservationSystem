package org.miu.edu.uicontrollers;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import org.miu.edu.dao.RoomDao;
import org.miu.edu.dao.impl.RoomDaoImpl;
import org.miu.edu.exceptions.TooManyBedsException;
import org.miu.edu.exceptions.WrongBedTypeException;
import org.miu.edu.model.Bed;
import org.miu.edu.model.BedStatus;
import org.miu.edu.model.BedType;
import org.miu.edu.model.RoomType;
import org.miu.edu.util.WindowUtil;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

public class BedController implements Initializable {

	@FXML
	private MenuItem addBedMenuItem;

	@FXML
	private Button btnAddBed;

	@FXML
	private Label lbRoomId;

	@FXML
	private Label lbRoomType;

	@FXML
	private TextField txtFieldBedID;

	@FXML
	private TextField txtFieldBedRate;

	@FXML
	private CheckBox checkboxUpper;

	@FXML
	private CheckBox checkBoxLower;

	@FXML
	private CheckBox checkBoxSingle;

	@FXML
	private CheckBox checkBoxDouble;	

	@FXML
	private MenuItem exitMenuItem;

	public static ObservableList<Bed> bedsData = FXCollections.observableArrayList();

	private RoomDao roomDao;

	private BedType bedType;

	private boolean isUpdate = false;

	@FXML
	private Text addEditBed;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		roomDao = new RoomDaoImpl();
	}

	public void setRoomId(int roomId) {
		lbRoomId.setText(String.valueOf(roomId));
		lbRoomId.setVisible(false);
	}

	public void setRoomType(RoomType roomType) {
		lbRoomType.setText("");
		lbRoomType.setText(roomType.name());

		if (roomType != RoomType.DORM)
			txtFieldBedRate.setDisable(true);
	}

	public void addUpdateBed(ActionEvent event) {
		if (txtFieldBedID.getText().isEmpty()) {
			WindowUtil.createAlert("Add Bed", "Please specify Bed ID !!!", AlertType.ERROR).showAndWait();
		} else if (bedType == null) {
			WindowUtil.createAlert("Add Bed", "Please choose bed type !!!", AlertType.ERROR).showAndWait();
		} else {
			if (isUpdate) {
				try {
					boolean result = false;
					
					if (txtFieldBedRate.getText().equalsIgnoreCase("0.0"))
						result = roomDao.updateBed(Integer.valueOf(lbRoomId.getText()), Integer.valueOf(txtFieldBedID.getText()),
								bedType, 0);
					else 
						result = roomDao.updateBed(Integer.valueOf(lbRoomId.getText()), Integer.valueOf(txtFieldBedID.getText()),
								bedType, Double.valueOf(txtFieldBedRate.getText()));
					if(result) {
						Alert alert = WindowUtil.createAlert("Bed Update", "Bed No. " + txtFieldBedID.getText() + " has been updated successfully !!!", AlertType.INFORMATION);
						Optional<ButtonType> result1 = alert.showAndWait();
						if (result1.get() == ButtonType.OK){
							WindowUtil.loadWindow("ViewAllRooms", event, this.getClass());
						}
					} else {
						WindowUtil.createAlert("Room Update", "Room update request failed !!!", AlertType.ERROR).showAndWait();
					}
				} catch (WrongBedTypeException e) {
					WindowUtil.createAlert("Bed Update", e.getMessage() + " !!!", AlertType.ERROR).showAndWait();
				}
			} else {
				Bed bed = null;

				if (txtFieldBedRate.getText().isEmpty())
					bed = new Bed(Integer.valueOf(txtFieldBedID.getText()), BedStatus.AVAILABLE, bedType);
				else
					bed = new Bed(Integer.valueOf(txtFieldBedID.getText()), BedStatus.AVAILABLE, Double.valueOf(txtFieldBedRate.getText()), bedType);

				int roomId = Integer.valueOf(lbRoomId.getText());
				try { 
					if (bed != null) {
						roomDao.addBedToRoom(roomId, bed);
						WindowUtil.createAlert("Add Bed", "Bed Added Successfully", AlertType.INFORMATION).showAndWait();
						clearFields();
					} 
				} catch (WrongBedTypeException ex) {
					WindowUtil.createAlert("Add Bed", "Added wrong bed type !!!", AlertType.ERROR).showAndWait();
				} catch (TooManyBedsException e) {
					WindowUtil.createAlert("Add Bed", "Maximum number of beds reached !!!", AlertType.ERROR).showAndWait();
				}	
			}
		}
	}

	private void clearFields() {
		txtFieldBedID.setText("");
		txtFieldBedRate.setText("");

		checkboxUpper.setSelected(false);
		checkBoxLower.setSelected(false);
		checkBoxSingle.setSelected(false);
		checkBoxDouble.setSelected(false);
	}

	public void editBed(Bed bed, RoomType roomType, int roomId) {
		setRoomType(roomType);
		setRoomId(roomId);
		addEditBed.setText("Edit Bed");
		btnAddBed.setText("Update");
		isUpdate = true;
		txtFieldBedID.setDisable(true);
		txtFieldBedID.setText(String.valueOf(bed.getId()));
		txtFieldBedRate.setText(String.valueOf(bed.getDailyRate()));

		if (bed.getBedType() == BedType.DOUBLE) {
			checkBoxDouble.setSelected(true);
			bedType = BedType.DOUBLE;
		} else if (bed.getBedType() == BedType.SINGLE) {
			checkBoxSingle.setSelected(true);
			bedType = BedType.SINGLE;
		} else if (bed.getBedType() == BedType.LOWER) {
			checkBoxLower.setSelected(true);
			bedType = BedType.LOWER;
		} else if (bed.getBedType() == BedType.UPPER) {
			checkboxUpper.setSelected(true);
			bedType = BedType.UPPER;
		}
	}

	public void viewAllRooms(ActionEvent event) {
		WindowUtil.loadWindow("ViewAllRooms", event, this.getClass());
	}

	@FXML
	private void handleCheckBoxBedType(ActionEvent event) {
		CheckBox checkBox = (CheckBox) event.getSource();
		if(checkboxUpper.isSelected() && checkBox.getId().equalsIgnoreCase("checkboxUpper")) {
			checkBoxLower.setSelected(false);
			checkBoxSingle.setSelected(false);
			checkBoxDouble.setSelected(false);
			bedType = BedType.UPPER;
		}

		if(checkBoxLower.isSelected() && checkBox.getId().equalsIgnoreCase("checkBoxLower")) {
			checkboxUpper.setSelected(false);
			checkBoxSingle.setSelected(false);
			checkBoxDouble.setSelected(false);
			bedType = BedType.LOWER;
		}

		if(checkBoxSingle.isSelected() && checkBox.getId().equalsIgnoreCase("checkBoxSingle")) {
			checkboxUpper.setSelected(false);
			checkBoxLower.setSelected(false);
			checkBoxDouble.setSelected(false);
			bedType = BedType.SINGLE;
		} 

		if(checkBoxDouble.isSelected() && checkBox.getId().equalsIgnoreCase("checkBoxDouble")) {
			checkboxUpper.setSelected(false);
			checkBoxLower.setSelected(false);
			checkBoxSingle.setSelected(false);
			bedType = BedType.DOUBLE;
		}
	}
}