package org.miu.edu.uicontrollers;

import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import org.miu.edu.dao.ReservationDao;
import org.miu.edu.dao.RoomDao;
import org.miu.edu.dao.impl.ReservationDaoImpl;
import org.miu.edu.dao.impl.RoomDaoImpl;
import org.miu.edu.model.Reservation;
import org.miu.edu.model.ReservationStatus;
import org.miu.edu.model.Room;
import org.miu.edu.model.UserType;
import org.miu.edu.model.dto.ReservationDTO;
import org.miu.edu.util.DateUtil;
import org.miu.edu.util.UserUtil;
import org.miu.edu.util.WindowUtil;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ViewAllReservationsController implements Initializable {

	@FXML
	private Button btnBackReservation;

	@FXML
	private Button btnAddReservation;

	@FXML
	private Button btnCheckOut;

	@FXML
	private Button btnCancel;

	@FXML
	private TableView<ReservationDTO> tblViewAllReservations;

	@FXML
	private  TableColumn<ReservationDTO, String> clmPersonalId;

	@FXML
	private  TableColumn<ReservationDTO, String> clmFirstName;

	@FXML
	private  TableColumn<ReservationDTO, String> clmLastName;

	@FXML
	private  TableColumn<ReservationDTO, String> clmAddress;

	@FXML
	private  TableColumn<ReservationDTO, String> clmPhone;

	@FXML
	private  TableColumn<ReservationDTO, String> clmCheckInDate;

	@FXML
	private  TableColumn<ReservationDTO, String> clmCheckOutDate;

	@FXML
	private  TableColumn<ReservationDTO, String> clmStatus;

	@FXML
	private  TableColumn<ReservationDTO, String> clmRoomNum;

	private ReservationDao reservationDao;

	ObservableList<ReservationDTO> reservationsData = FXCollections.observableArrayList();

	ReservationDTO selectedReservation;

	private RoomDao roomDao;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		reservationDao = new ReservationDaoImpl();
		roomDao = new RoomDaoImpl();

		clmPersonalId.setCellValueFactory(new PropertyValueFactory<ReservationDTO, String>("personalID"));
		clmFirstName.setCellValueFactory(new PropertyValueFactory<ReservationDTO, String>("firstName"));
		clmLastName.setCellValueFactory(new PropertyValueFactory<ReservationDTO, String>("lastName"));
		clmAddress.setCellValueFactory(new PropertyValueFactory<ReservationDTO, String>("address"));
		clmPhone.setCellValueFactory(new PropertyValueFactory<ReservationDTO, String>("phoneNumber"));
		clmCheckInDate.setCellValueFactory(new PropertyValueFactory<ReservationDTO, String>("checkInDate"));
		clmCheckOutDate.setCellValueFactory(new PropertyValueFactory<ReservationDTO, String>("checkOutDate"));
		clmStatus.setCellValueFactory(new PropertyValueFactory<ReservationDTO, String>("reservationStatus"));
		clmRoomNum.setCellValueFactory(new PropertyValueFactory<ReservationDTO, String>("roomNumber"));

		this.getAllReservations();
		loadReservations(reservationsData);
		btnCancel.setDisable(true);
		btnCheckOut.setDisable(true);
	}

	public ObservableList<ReservationDTO> getReservationsData() {
		return reservationsData;
	}

	private void loadReservations(ObservableList<ReservationDTO> reservationsData2) {
		tblViewAllReservations.setItems(getReservationsData());

		tblViewAllReservations.setRowFactory(tv -> {
			TableRow<ReservationDTO> row = new TableRow<>();
			row.setOnMouseClicked(event -> {
				if (event.getClickCount() == 1 && (!row.isEmpty())) {
					selectedReservation = row.getItem();
					btnCancel.setDisable(false);
					if (UserUtil.getLoggedInUser().getUserType() == UserType.BOTH)
						btnCheckOut.setDisable(false);
				}
			});
			return row;
		});
	}

	private void getAllReservations() {
		reservationsData.clear();
		List<Reservation> reservations = reservationDao.getAllReservations(true);
		for (Reservation reservation : reservations) {
			String roomNumber = "";
			String bedNumber = "";

			if (reservation.getSummary() != null) {
				String details[] = reservation.getSummary().split("-");
				roomNumber = details[0];
				if (details.length == 2)
					bedNumber = details[1];
			}

			reservationsData.add(new ReservationDTO(reservation.getReservationId(), DateUtil.getFormattedDate(reservation.getCheckInDate()), 
					DateUtil.getFormattedDate(reservation.getCheckOutDate()), 
					reservation.getGuest().getAddress(), reservation.getGuest().getFirstName(), reservation.getGuest().getLastName(), 
					reservation.getGuest().getPhoneNumber(), reservation.getGuest().getPersonalID(), roomNumber, bedNumber,
					reservation.getPaymentType(), reservation.getReservationStatus(), reservation));
		}
	}

	public void checkOut(ActionEvent event) {
		if (selectedReservation != null) {
			if (selectedReservation.getReservationStatus() != ReservationStatus.CHECKED_OUT && 
					selectedReservation.getReservationStatus() == ReservationStatus.ACTIVE) {
				Alert alert = WindowUtil.createAlert("CheckOut", "Are you sure you want to check-out ?", AlertType.CONFIRMATION);
				Optional<ButtonType> result = alert.showAndWait();
				if (result.get() == ButtonType.OK){
					String bedNo = selectedReservation.getBedNumber();
					String roomNo = selectedReservation.getRoomNumber();
					Reservation reservation = reservationDao.performCheckOut(selectedReservation.getReservationId());
					Room room = roomDao.performCheckOut(Integer.valueOf(roomNo), bedNo);

					if (room != null && reservation != null) {
						Alert alert1 = WindowUtil.createAlert("CheckOut", "Bed Number " + bedNo + " in Room No " + roomNo + " is now free !!!", AlertType.INFORMATION);
						Optional<ButtonType> result1 = alert1.showAndWait();
						if (result1.get() == ButtonType.OK){
							getAllReservations();
							tblViewAllReservations.refresh();
						}
					} else {
						WindowUtil.createAlert("CheckOut", "CheckOut Request Failed !!!", AlertType.ERROR).showAndWait();
					}
				}
			} else {
				WindowUtil.createAlert("CheckOut", "CheckOut has already been done !!!", AlertType.ERROR).showAndWait();
			}
		} else {
			WindowUtil.createAlert("CheckOut", "Please select a reservation !!!", AlertType.ERROR).showAndWait();
		}
	}

	public void cancelReservation(ActionEvent event){
		if (selectedReservation != null) {
			if (selectedReservation.getReservationStatus() != ReservationStatus.CANCELLED) {
				Alert alert = WindowUtil.createAlert("Cancel Reservation", "Are you sure you want to cancel reservation ?", AlertType.CONFIRMATION);
				Optional<ButtonType> result = alert.showAndWait();
				if (result.get() == ButtonType.OK){
					//24 hrs prior to check in time 
					//
					Date checkInDate = selectedReservation.getReservation().getCheckInDate();

					if (DateUtil.getTimeDifference(checkInDate, new Date()) < 24) {
						WindowUtil.createAlert("Cancel Reservation", "Reservations can only be cancelled 24 hrs or more to check-in time !!!", AlertType.ERROR).showAndWait();
					} else {
						String bedNo = selectedReservation.getBedNumber();
						String roomNo = selectedReservation.getRoomNumber();
						Room room = roomDao.performCheckOut(Integer.valueOf(roomNo), bedNo);
						Reservation reservation = reservationDao.cancelReservation(selectedReservation.getReservationId());

						if (room != null && reservation != null) {
							Alert alert1 = WindowUtil.createAlert("Cancel Reservation", "Reservation for guest [" + selectedReservation.getFirstName() + " - " 
									+ selectedReservation.getFirstName() + "] has been cancelled !!!", AlertType.INFORMATION);
							Optional<ButtonType> result1 = alert1.showAndWait();
							if (result1.get() == ButtonType.OK){
								getAllReservations();
								tblViewAllReservations.refresh();
							}
						} else {
							WindowUtil.createAlert("Cancel Reservation", "Reservation cancelling request failed !!!", AlertType.ERROR).showAndWait();
						}
					}
				} 
			} else {
				WindowUtil.createAlert("Cancel Reservation", "Reservation is already cancelled !!!", AlertType.ERROR).showAndWait();
			}
		} else {
			WindowUtil.createAlert("Cancel Reservation", "Please select a reservation !!!", AlertType.ERROR);
		}
	}

	public void goHomeView(ActionEvent event) {
		if (UserUtil.getLoggedInUser().getUserType() == UserType.BOTH)
			WindowUtil.loadWindow("BothRole", event, this.getClass());
		else if (UserUtil.getLoggedInUser().getUserType() == UserType.USER)
			WindowUtil.loadWindow("User", event, this.getClass());
	}
	public void addAnotherReservation(ActionEvent event) {
		WindowUtil.loadWindow("SearchAvailableRoom", event, this.getClass());
	}
}