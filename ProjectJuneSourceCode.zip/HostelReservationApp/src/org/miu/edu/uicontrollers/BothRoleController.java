package org.miu.edu.uicontrollers;

import java.net.URL;
import java.util.ResourceBundle;

import org.miu.edu.util.WindowUtil;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

public class BothRoleController implements Initializable  {

	@FXML
	private Button btnAddRooms;
	
	@FXML
	private Button btnListRooms;
	
	@FXML
	private Button btnAddReservation;
	
	@FXML
	private Button btnListReservation;

	@Override
	public void initialize(URL location, ResourceBundle resources) {}

	public void AddRoom(ActionEvent event) {
		WindowUtil.loadWindow("AddEditRoom", event, this.getClass());
	}

	public void addReservation(ActionEvent event) {
		WindowUtil.loadWindow("SearchAvailableRoom", event, this.getClass());  
	}

	public void listRooms(ActionEvent event) {
		WindowUtil.loadWindow("ViewAllRooms", event, this.getClass()); 
	}

	public void ListReservation(ActionEvent event) {
		WindowUtil.loadWindow("ViewAllReservations", event, this.getClass()); 
	}

	public void onLogOut(ActionEvent event) {
		WindowUtil.loadWindow("Login", event, this.getClass());
	}
}