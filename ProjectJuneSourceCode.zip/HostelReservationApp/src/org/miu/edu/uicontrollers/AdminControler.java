package org.miu.edu.uicontrollers;

import java.net.URL;
import java.util.ResourceBundle;

import org.miu.edu.util.WindowUtil;
import org.miu.edu.util.UserUtil;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

public class AdminControler implements Initializable {
	
	@FXML
	private Button btnAddBtn1;
	
	@FXML
	private Button btnAddBtn2;
	
	@FXML
	private Button btnListBed1;
	
	@FXML
	private Button btnListRooms;

	@Override
	public void initialize(URL location, ResourceBundle resources) {}
	
	public void addRoomMtd(ActionEvent event) {
		WindowUtil.loadWindow("AddEditRoom", event, this.getClass());
	}
	
	public void onLogOut(ActionEvent event) {
		UserUtil.setLoggedInUser(null);
		WindowUtil.loadWindow("Login", event, this.getClass());
	}
	
	//list all rooms
	public void listRooms(ActionEvent event) {
		WindowUtil.loadWindow("ViewAllRooms", event, this.getClass());
	}
	
    public void loadListOfBeds(ActionEvent event) {
    	WindowUtil.loadWindow("ViewAllBeds", event, this.getClass());
		
	}
}